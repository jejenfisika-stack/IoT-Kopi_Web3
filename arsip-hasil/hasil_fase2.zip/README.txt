Arsip Hasil Fase 2
==================

Keluaran numerik dari forecasting-model/Fase2_Perbandingan_Model.ipynb,
yang menjadi dasar seluruh tabel di naskah "Diagnose Before You Train".

Isi
---
tabel1_praproses.csv          ringkasan pra-pemrosesan per variabel
tabel2_hasil.csv              MAE/RMSE/MASE tiap model x horizon,
                              lengkap dengan selang kepercayaan bootstrap
tabel3_diebold_mariano.csv    540 uji Diebold-Mariano berpasangan
tabel4_juara_horizon.csv      model terbaik tiap variabel dan horizon

Sumber data
-----------
dataset/sesi_20260824-20260829.csv
SHA-256 92025679db8c2ab50123ebe812ace209f60643cd0c229ac16aca5e1c44454690

Keterulangan
------------
Arsip ini dibangun oleh arsip-hasil/bangun_arsip.py dengan seluruh stempel
waktu dipaku, sehingga sidik jarinya dapat dihitung ulang oleh siapa pun.
Menjalankan ulang notebook tidak menghasilkan berkas yang identik byte demi
byte -- pustaka numerik berbeda di digit terakhir antar versi. Keterulangan
diperiksa terhadap angka di dalam tabel pada ketelitian yang tercetak,
sedangkan sidik jari di blockchain menjawab pertanyaan lain: apakah tabel ini
berubah sejak ditambatkan.
